# COMP3123 Assignment 1
**Student Name:** Omar Romero Garcia  
**Student ID:** 101533489  
**Course:** COMP3123 – Full Stack Development

## Description
This project implements a RESTful API using Node.js, Express, and MongoDB.  
It allows user signup/login and employee management (CRUD operations).

## Features
- User registration and login  
- Create, read, update, and delete employees  
- Connected to MongoDB Atlas  
- Tested with Postman

## Instructions to Run
1. Clone the project  
2. Run `npm install`  
3. Create a `.env` file and set your MongoDB connection string and port  
4. Run `npm run dev`  
5. Test endpoints in Postman using the provided collection

## Files Included
- `/src` → Project source code  
- `/screenshots` → Postman screenshots  
- `.env.example` → Example environment variables  
- `101533489_COMP3123_assignment1.postman_collection.json` → Exported Postman collection  
- `README.md` → Project info
