import { Router } from "express";
import { body } from "express-validator";
import { signup, login } from "../controllers/user.controller.js";
import { validate } from "../middleware/validate.js";

const router = Router();

router.post(
  "/signup",
  [
    body("username").trim().notEmpty(),
    body("email").isEmail(),
    body("password").isLength({ min: 6 })
  ],
  validate,
  signup
);

router.post(
  "/login",
  [
    body("password").isLength({ min: 6 }),
    body().custom((val) => {
      if (!val.email && !val.username) throw new Error("email or username is required");
      return true;
    })
  ],
  validate,
  login
);

export default router;
