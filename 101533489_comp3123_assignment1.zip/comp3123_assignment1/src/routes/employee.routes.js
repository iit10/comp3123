import { Router } from "express";
import { body } from "express-validator";
import { validate } from "../middleware/validate.js";
import {
  listEmployees, createEmployee, getEmployee, updateEmployee, deleteEmployee
} from "../controllers/employee.controller.js";

const router = Router();

router.get("/employees", listEmployees);

router.post(
  "/employees",
  [
    body("first_name").notEmpty(),
    body("last_name").notEmpty(),
    body("email").isEmail(),
    body("position").notEmpty(),
    body("salary").isFloat({ min: 0 }),
    body("date_of_joining").isISO8601(),
    body("department").notEmpty()
  ],
  validate,
  createEmployee
);

router.get("/employees/:eid", getEmployee);

router.put(
  "/employees/:eid",
  [
    body("email").optional().isEmail(),
    body("salary").optional().isFloat({ min: 0 }),
    body("date_of_joining").optional().isISO8601()
  ],
  validate,
  updateEmployee
);

router.delete("/employees", deleteEmployee);

export default router;
