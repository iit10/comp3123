import Employee from "../models/Employee.js";
import mongoose from "mongoose";

export const listEmployees = async (_req, res) => {
  const employees = await Employee.find().lean();
  const mapped = employees.map(e => ({
    employee_id: e._id,
    first_name: e.first_name,
    last_name: e.last_name,
    email: e.email,
    position: e.position,
    salary: e.salary,
    date_of_joining: e.date_of_joining,
    department: e.department
  }));
  return res.status(200).json(mapped);
};

export const createEmployee = async (req, res) => {
  try {
    const emp = await Employee.create(req.body);
    return res.status(201).json({
      message: "Employee created successfully.",
      employee_id: emp._id
    });
  } catch (e) {
    return res.status(400).json({ status: false, message: e.message });
  }
};

export const getEmployee = async (req, res) => {
  const { eid } = req.params;
  if (!mongoose.isValidObjectId(eid)) {
    return res.status(400).json({ status: false, message: "Invalid ID" });
  }
  const emp = await Employee.findById(eid).lean();
  if (!emp) return res.status(404).json({ status: false, message: "Not found" });
  return res.status(200).json({
    employee_id: emp._id,
    first_name: emp.first_name,
    last_name: emp.last_name,
    email: emp.email,
    position: emp.position,
    salary: emp.salary,
    date_of_joining: emp.date_of_joining,
    department: emp.department
  });
};

export const updateEmployee = async (req, res) => {
  const { eid } = req.params;
  if (!mongoose.isValidObjectId(eid)) {
    return res.status(400).json({ status: false, message: "Invalid ID" });
  }
  const upd = await Employee.findByIdAndUpdate(eid, req.body, { new: true, runValidators: true });
  if (!upd) return res.status(404).json({ status: false, message: "Not found" });
  return res.status(200).json({ message: "Employee details updated successfully." });
};

export const deleteEmployee = async (req, res) => {
  const { eid } = req.query;
  if (!mongoose.isValidObjectId(eid)) {
    return res.status(400).json({ status: false, message: "Invalid ID" });
  }
  await Employee.findByIdAndDelete(eid);
  return res.status(204).send();
};
