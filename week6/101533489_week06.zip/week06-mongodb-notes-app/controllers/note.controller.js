const Note = require('../models/note.model');

// Create
exports.createNote = async (req, res) => {
  try {
    const payload = req.body.content ?? req.body; // supports README sample shape
    const note = await Note.create(payload);
    res.status(201).json({ ok: true, data: note });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
};

// Read all
exports.getNotes = async (_req, res) => {
  const notes = await Note.find().sort({ dateUpdated: -1 });
  res.json({ ok: true, count: notes.length, data: notes });
};

// Read one
exports.getNote = async (req, res) => {
  try {
    const note = await Note.findById(req.params.id);
    if (!note) return res.status(404).json({ ok: false, error: 'Not found' });
    res.json({ ok: true, data: note });
  } catch (err) {
    res.status(400).json({ ok: false, error: 'Invalid id' });
  }
};

// Update
exports.updateNote = async (req, res) => {
  try {
    const payload = req.body.content ?? req.body;
    const note = await Note.findByIdAndUpdate(req.params.id, payload, { new: true, runValidators: true });
    if (!note) return res.status(404).json({ ok: false, error: 'Not found' });
    res.json({ ok: true, data: note });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
};

// Delete
exports.deleteNote = async (req, res) => {
  try {
    const note = await Note.findByIdAndDelete(req.params.id);
    if (!note) return res.status(404).json({ ok: false, error: 'Not found' });
    res.json({ ok: true, message: 'Deleted' });
  } catch (err) {
    res.status(400).json({ ok: false, error: 'Invalid id' });
  }
};
