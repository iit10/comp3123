const mongoose = require('mongoose');

const NoteSchema = new mongoose.Schema(
  {
    noteTitle:       { type: String, required: true, trim: true },
    noteDescription: { type: String, required: true, trim: true },
    priority:        { type: String, enum: ['LOW', 'MEDIUM', 'HIGH'], default: 'LOW' }
  },
  { timestamps: { createdAt: 'dateAdded', updatedAt: 'dateUpdated' } }
);

module.exports = mongoose.model('Note', NoteSchema);
