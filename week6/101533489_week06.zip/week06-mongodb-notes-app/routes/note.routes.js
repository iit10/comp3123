const router = require('express').Router();
const ctrl = require('../controllers/note.controller');

router.post('/', ctrl.createNote);
router.get('/', ctrl.getNotes);
router.get('/:id', ctrl.getNote);
router.put('/:id', ctrl.updateNote);
router.delete('/:id', ctrl.deleteNote);

module.exports = router;
